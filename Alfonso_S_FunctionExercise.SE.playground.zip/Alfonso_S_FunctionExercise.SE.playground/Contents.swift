struct EnguineType {
    var decent = 180
    var fastest = 200
    var affordable = 150
    var effeciant = 198
    var expensive = 200
}

let myEnguineType = EnguineType()

print("The fastest enguine of the cars can go around  \(myEnguineType.fastest) mph.")




